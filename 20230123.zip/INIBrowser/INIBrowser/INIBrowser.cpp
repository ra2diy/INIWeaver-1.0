﻿
#include "FromEngine/Include.h"
#include "PreLink.h"


#if defined(_MSC_VER) && (_MSC_VER >= 1900) && !defined(IMGUI_DISABLE_WIN32_FUNCTIONS)
#pragma comment(lib, "legacy_stdio_definitions")
#endif

// 此回调函数为全局函数或静态函数;
int CALLBACK BrowseCallbackProc(HWND hwnd, UINT uMsg, LPARAM lParam, LPARAM lpData)
{
    (void)lParam;
    switch (uMsg)
    {
    case BFFM_INITIALIZED:
    {
        ::SendMessage(hwnd, BFFM_SETSELECTION, TRUE, (LPARAM)lpData);
    }
    break;
    default:
        break;
    }
    return 0;
}

bool SelectFilePath(HWND father, std::wstring& strFilePath, const std::wstring& FromPath)//No Unicode
{
    TCHAR szPathName[MAX_PATH] = { 0 };
    BROWSEINFOW bInfo = { 0 };
    bInfo.hwndOwner = father;// 父窗口;
    bInfo.lpszTitle = L"选择目录";
    bInfo.ulFlags = BIF_RETURNONLYFSDIRS | BIF_USENEWUI
        | BIF_UAHINT | BIF_SHAREABLE;
    // 关于更多的 ulFlags 参考 http://msdn.microsoft.com/en-us/library/bb773205(v=vs.85).aspx;
    bInfo.lpfn = (BrowseCallbackProc);
    bInfo.lParam = (LPARAM)(LPCTSTR)(FromPath.c_str());// 注意路径中不要带'\..\'或'\.\'符号，否则设置默认路径失败;

    LPITEMIDLIST lpDlist;
    lpDlist = SHBrowseForFolderW(&bInfo);
    if (nullptr == lpDlist) // 单击了取消或×按钮;
    {
        strFilePath.clear();
        return false;
    }
    SHGetPathFromIDListW(lpDlist, szPathName);
    strFilePath = szPathName;
    return true;
}

int WINAPI wWinMain(_In_ HINSTANCE hInstance,
    _In_opt_ HINSTANCE hPrevInstance,
    _In_ LPWSTR    lpCmdLine,
    _In_ int       nCmdShow)
{
    using namespace PreLink;

    (void)hPrevInstance;
    (void)lpCmdLine;
    (void)nCmdShow;

    GlobalLog.ClearLog();
    GlobalLogB.ClearLog();

    GlobalLog.AddLog_CurTime(false);
    GlobalLog.AddLog(("INI浏览器 V" + Version).c_str());
    GlobalLog.AddLog_CurTime(false);
    GlobalLog.AddLog("INI浏览器已开始运行。");


    hInst = hInstance;
    //auto _lpwCmdLine = L"/800*0<FFFFFF>";   //V1.0b3 IHS
    //auto _lpwCmdLine = lpCmdLine;   //V1.0b5 IHS

    RScrX = GetSystemMetrics(SM_CXSCREEN);
    RScrY = GetSystemMetrics(SM_CYSCREEN);

    { //V1.0b5 IHS
        ExtFileClass DynamicData;
        if (DynamicData.Open(".\\Resources\\dynamic.dat", "rb"))
        {
            int64_t ScrXR, ScrYR;
            DynamicData.ReadData(ScrXR);
            DynamicData.ReadData(ScrYR);
            double SectionTextScaleR;
            DynamicData.ReadData(SectionTextScaleR);
            SectionTextScale = PrevSTScale = (float)SectionTextScaleR;
            DynamicData.ReadData(_TempView::OffsetPos.x);
            DynamicData.ReadData(_TempView::OffsetPos.y);
            PrevOffsetPos = _TempView::OffsetPos;

            ScrX = (int)ScrXR;
            ScrY = (int)ScrYR;
            if (ScrX <= 0 || ScrY <= 0)
            {
                ScrX = 1280;
                ScrY = 720;
            }
        }
        else //缺省值
        {
            ScrX = 1280;
            ScrY = 720;
            SectionTextScale = PrevSTScale = 1.0f;
        }
        CurrentScreenWidth = ScrX;
        CurrentScreenHeight = ScrY;
    }
    ::srand((unsigned)::time(NULL));
    GlobalRnd = std::default_random_engine{ (unsigned)::time(NULL) };
    if (EnableLog)
    {
        GlobalLog.AddLog_CurTime(false);
        GlobalLog.AddLog("设置随机数引擎。");

        GlobalLog.AddLog_CurTime(false);
        GlobalLog.AddLog(("读入输入参数 X=" + std::to_string(ScrX) + " Y=" + std::to_string(ScrY)).c_str());
    }


    char DesktopTmp[300];
    SHGetSpecialFolderPathA(0, DesktopTmp, CSIDL_DESKTOPDIRECTORY, 0);
    GetCurrentDirectoryW(MAX_PATH, CurrentDirW);
    GetCurrentDirectoryA(MAX_PATH, CurrentDirA);
    Desktop = DesktopTmp;
    Defaultpath = MBCStoUnicode(Desktop);

    int PreLoopRet = PreLoop1();
    if (PreLoopRet)return PreLoopRet;


    if (EnableLog)
    {
        GlobalLog.AddLog_CurTime(false);
        GlobalLog.AddLog("渲染初始化完成。");
    }

    std::thread FrontThr(IBF_Thr_FrontLoop);
    FrontThr.detach();

    PreLoop2();

    _TempView::ViewSize = { FontHeight * 8.0f, FontHeight * 8.0f };

   

    ShellLoop();
    CleanUp();

    return 0;
}

