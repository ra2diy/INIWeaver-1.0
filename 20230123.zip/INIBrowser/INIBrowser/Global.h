#pragma once

#include "IBFront.h"
#include "IBRender.h"
#include "FromEngine/RFBump.h"
#include <atomic>

#define IBD_ShutDownDestructor(x) x##_ShutDownDestructor
#define IBD_Inst_ShutDownDestructor(x) x##_Inst_ShutDownDestructor
#define IBD_ShutDownDtorClass(x,fn) \
struct IBD_ShutDownDestructor(x)\
{\
    IBD_ShutDownDestructor(x)() {}\
    ~IBD_ShutDownDestructor(x)() { fn(); }\
}IBD_Inst_ShutDownDestructor(x)

#define IBD_BoolStr(v) ((v)?"true":"false")

//���а汾���������
extern const std::string Version;
extern const int VersionMajor;
extern const int VersionMinor;
extern const int VersionRelease;
extern const int VersionN;
extern const std::string VersionNStr;

//ͳһ���ļ�ͷ
extern const int32_t SaveFileHeaderSign;

//���õ�ʵ��
extern IBF_Setting IBF_Inst_Setting;
extern IBR_Setting IBR_Inst_Setting;

//���õı�ʶ
extern std::atomic<bool> SettingLoadComplete;
extern std::atomic<bool> SettingSaveComplete;
extern const char* SettingFileName;

//��־
extern LogClass GlobalLog;
extern LogClass GlobalLogB;
extern BufString LogBuf, LogBufB;
extern bool EnableLog;//LOG
extern bool EnableLogEx;//EXTRA LOG

//�߳���Ϣ����
extern IBRF_Bump IBRF_CoreBump;
#define IBD_RInterruptF(x) IBG_RInterruptF_RangeLock __IBD_RInterruptF_VariableA_##x{ IBRF_CoreBump };
#define IBD_FInterruptR(x) IBG_FInterruptR_RangeLock __IBD_FInterruptR_VariableA_##x{ IBRF_CoreBump };
#define IBD_RInterruptMsgF(msg) IBG_Interrupt(IBRF_CoreBump.FInterruptLock,msg)
#define IBD_FInterruptMsgR(msg) IBG_Interrupt(IBRF_CoreBump.RInterruptLock,msg)
extern uint64_t ShellLoopLastTime;
extern DWORD BackThreadID;

//��������
extern int KeyPerPage;
extern int FontHeight;

//��ʽ���ͱ�
extern IBF_DefaultTypeList IBF_Inst_DefaultTypeList;
extern IBF_DefaultModuleList IBF_Inst_DefaultModuleList;
extern IBF_Project IBF_Inst_Project;
extern IBR_Project IBR_Inst_Project;
#define RCommand(x) IBR_Inst_Project.##x

//����
extern IBR_Debug IBR_Inst_Debug;

//�������
extern std::default_random_engine GlobalRnd;
extern const int ModuleRandomParameterLength;
