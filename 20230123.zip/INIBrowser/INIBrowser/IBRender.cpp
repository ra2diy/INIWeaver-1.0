
#include "IBRender.h"
#include "IBFront.h"
#include "Global.h"
#include "FromEngine/RFBump.h"
#include "FromEngine/global_timer.h"

bool IBR_Setting::IsReadSettingComplete()
{
    return SettingLoadComplete.load();
}

bool IBR_Setting::IsSaveSettingComplete()
{
    return SettingSaveComplete.load();
}

void IBR_Setting::SetSettingName(const char* Name)
{
    SettingName = Name;
}

void IBR_Setting::CallReadSetting()
{
    SettingLoadComplete.store(false);
    IBRF_CoreBump.IBR_SendToF({ [=]() {IBF_Inst_Setting.ReadSetting(SettingName); } });
}
void IBR_Setting::CallSaveSetting()
{
    SettingSaveComplete.store(false);
    IBRF_CoreBump.IBR_SendToF({ [=]() {IBF_Inst_Setting.SaveSetting(SettingName); } });
}

std::vector<IBF_SettingType> IBR_Inst_Setting_UIList;


void IBR_Setting::RenderUI()
{
    static bool Called = false;
    static bool First = true;
    static std::string DescLong = "";
    static ETimer::TimerClass Timer;

    if (Timer.GetClock() <= ETimer::__DurationZero || First)
    {
        First = false;
        CallSaveSetting();
        Timer.Set(ETimer::SecondToDuration(5));
    }

    if (IBR_Inst_Setting_UIList.empty())
    {
        if (!Called)
        {
            IBRF_CoreBump.IBR_SendToF({ [this]()
            {
                IBF_Inst_Setting.UploadSettingBoard([](const std::vector<IBF_SettingType>& Vec)
                    {
                        IBR_Inst_Setting_UIList = Vec;
                    });
            }});
            Called = true;
        }
        ImGui::TextDisabled(u8"���������б��С���");
    }
    else
    {
        auto CRgMax = ImGui::GetWindowContentRegionMax(), CRgMin = ImGui::GetWindowContentRegionMin();

        ImGui::Text(u8"�����޸Ľ�����������Ч");

        ImGui::BeginChild(113007, { CRgMax.x - CRgMin.x , CRgMax.y - CRgMin.y - FontHeight * 10.0f },
            false,ImGuiWindowFlags_NoMove | ImGuiWindowFlags_AlwaysUseWindowPadding);
        bool Appear = false;
        for (auto& Li : IBR_Inst_Setting_UIList)
        {
            if (Li.Action())
            {
                DescLong = Li.DescLong;
                Appear = true;
            }
        }

        ImGui::NewLine();
        ImGui::NewLine();
        if (ImGui::Button(u8"��Config.ini"))
            ::ShellExecuteA(nullptr, "open", ".\\Resources\\Config.ini", NULL, NULL, SW_SHOWNORMAL);
        if (ImGui::IsItemHovered())
        {
            DescLong = u8"һ�������ô���ᵼ���޷���������\n�����������޸�\n�ⲿ�����÷���Config.ini��\n�Ķ�������������Ч";
            Appear = true;
        }

        if (!Appear)DescLong = "";

        ImGui::EndChild();

        ImGui::BeginChildFrame(113003, { CRgMax.x - CRgMin.x , FontHeight * 6.0f });
        ImGui::TextWrapped(DescLong.c_str());
        ImGui::EndChildFrame();
    }
}







const IBB_Section_Desc IBB_Section_DescNull{"",""};


void IBR_Debug::AddMsgCycle(const StdMessage& Msg)
{
    DebugVec.push_back(Msg);
}
void IBR_Debug::AddMsgOnce(const StdMessage& Msg)
{
    DebugVecOnce.push_back(Msg);
}
void IBR_Debug::ClearMsgCycle()
{
    DebugVec.clear();
}

void IBR_Debug::RenderUI()
{
    if (UICond.LoopShow){ if (ImGui::ArrowButton("loopc", ImGuiDir_Down))UICond.LoopShow = false; }
    else { if (ImGui::ArrowButton("loopa", ImGuiDir_Right))UICond.LoopShow = true; }
    if (UICond.LoopShow)for (auto x : DebugVec)x();

    if (UICond.OnceShow){ if (ImGui::ArrowButton("loopd", ImGuiDir_Down))UICond.OnceShow = false; }
    else { if (ImGui::ArrowButton("loopb", ImGuiDir_Right))UICond.OnceShow = true; }
    ImGui::SameLine();
    if (ImGui::Button(u8"CLEAR"))DebugVecOnce.clear();
    if (UICond.OnceShow)for (auto x : DebugVecOnce)x();
}

void IBR_Debug::RenderUIOnce()
{
    _CALL_CMD IBR_Inst_Project.AddModule(u8"GenUnit1", { u8"LBWNB" }, IBB_Section_DescNull);
    _CALL_CMD IBR_Inst_Project.AddModule(u8"Weapons", { u8"FuckPrimary",u8"FuckSecondary" }, IBB_Section_Desc{ "Rule","LBWNB" });

    GlobalLog.AddLog_CurTime(false); GlobalLog.AddLog("DEBUG_DATA");

    bool RA = _CALL_CMD IBR_Inst_Project.CreateSection(IBB_Section_Desc{ "Rule","LBWNB" });
    bool RB = _CALL_CMD IBR_Inst_Project.CreateSection(IBB_Section_Desc{ "Rule","LZNB" });
    GlobalLog.AddLog_CurTime(false); GlobalLog.AddLog(IBD_BoolStr(RA));
    GlobalLog.AddLog_CurTime(false); GlobalLog.AddLog(IBD_BoolStr(RB));

    {
        IBD_RInterruptF(x);
        IBR_Section SK = _CALL_CMD IBR_Inst_Project.GetSection(IBB_Section_Desc{ "Rule","LZNB" });
        GlobalLog.AddLog_CurTime(false); GlobalLog.AddLog(SK.GetBack());
        SK.GetBack()->VarList.Value["_Local_Category"] = "Infantry";
        SK.GetBack()->VarList.Value["_Local_AtFile"] = "Rule";
    }

    _CALL_CMD IBR_Inst_Project.AddModule(u8"Weapons", { u8"FuckPrimary",u8"FuckSecondary" }, IBB_Section_Desc{ "Rule","LZNB" });


    IBR_Section SC = _CALL_CMD IBR_Inst_Project.GetSection(IBB_Section_Desc{ "Rule","LZNB" });
    bool RSC = _CALL_CMD SC.Register("InfantryTypes", "Rule");

    bool RC = _CALL_CMD SC.DuplicateSection(IBB_Section_Desc{ "Rule","LZNB_II" });
    IBR_Section SD = _CALL_CMD IBR_Inst_Project.GetSection(IBB_Section_Desc{ "Rule","LZNB_II" });

    GlobalLog.AddLog_CurTime(false); GlobalLog.AddLog(SC.GetBack());
    GlobalLog.AddLog_CurTime(false); GlobalLog.AddLog(SD.GetBack());
    GlobalLog.AddLog_CurTime(false); GlobalLog.AddLog(IBD_BoolStr(RSC));
    GlobalLog.AddLog_CurTime(false); GlobalLog.AddLog(IBD_BoolStr(RC));

    {
        IBD_RInterruptF(x);
        auto sdp = SD.GetBack();
        GlobalLog.AddLog_CurTime(false); GlobalLog.AddLog(sdp->SubSecs.size());
        if (!sdp->SubSecs.empty())
        {
            auto GLine = sdp->SubSecs.at(0).Lines.begin()->second;
            GlobalLog.AddLog_CurTime(false); GlobalLog.AddLog(GLine.Default);
            GlobalLog.AddLog_CurTime(false); GlobalLog.AddLog(GLine.Default->Name.c_str());
            GlobalLog.AddLog_CurTime(false); GlobalLog.AddLog(GLine.Default->Property.Type.c_str());
            auto proc = GLine.Default->Property.Proc;
            GlobalLog.AddLog_CurTime(false); GlobalLog.AddLog(proc);
            GlobalLog.AddLog_CurTime(false); GlobalLog.AddLog(proc->GetString(GLine.Data).c_str());
            proc->SetValue(GLine.Data, "WTF_AHHH");
            _CALL_CMD IBR_Inst_Project.UpdateAll();
            _CALL_CMD IBR_Inst_Project.UpdateAll();
            _CALL_CMD IBR_Inst_Project.UpdateAll();
            GlobalLog.AddLog_CurTime(false); GlobalLog.AddLog(proc->GetString(GLine.Data).c_str());
        }
    }

    IBR_Section SKA = _CALL_CMD IBR_Inst_Project.GetSection(IBB_Section_Desc{ "Rule","FuckSecondary" });
    SKA.Rename("FuckSecondary_NewName");

    //_CALL_CMD IBR_Inst_Project.ForceUpdate();


    std::string s = _CALL_CMD IBR_Inst_Project.GetText(true);

    if (EnableLog)
    {
        GlobalLog.AddLog_CurTime(false);
        GlobalLog.AddLog("�����ı���\"");
        GlobalLog.AddLog(UTF8toMBCS(s).c_str(),false);
        GlobalLog.AddLog("\"");
    }
}

void IBR_Debug::DebugLoad()
{
    IBF_Inst_DefaultTypeList.ReadSetting(".\\Global\\DefaultTypeList.json");
    IBF_Inst_DefaultModuleList.ReadSetting(".\\Global\\DefaultModuleList.json");
}



IBB_Section_Desc& IBR_Section::GetDesc() const
{
    return Root->IBR_SectionMap[ID];
}
IBB_Section* IBR_Section::GetBack_Inl() const
{
    return const_cast<IBB_Section*>(IBF_Inst_Project.Project.GetSec(IBB_Project_Index{ GetDesc() }));
}

IBB_Section* _PROJ_CMD_READ IBR_Section::GetBack()
{
    IBD_RInterruptF(x);
    return GetBack_Inl();
}
const IBB_Section* _PROJ_CMD_READ IBR_Section::GetBack() const
{
    IBD_RInterruptF(x);
    return GetBack_Inl();
}
bool _PROJ_CMD_READ IBR_Section::HasBack() const
{
    IBD_RInterruptF(x);
    return GetBack_Inl() != nullptr;
}
_RETURN_BACK_DATA IBB_VariableList* _PROJ_CMD_READ IBR_Section::GetVarList() _PROJ_CMD_BACK_CONST const
{
    IBD_RInterruptF(x);
    auto pSec = GetBack_Inl();
    if (pSec == nullptr)return nullptr;
    return &(pSec->VarList);
}
IBB_VariableList _PROJ_CMD_READ IBR_Section::GetVarListCopy() _PROJ_CMD_BACK_CONST const
{
    IBD_RInterruptF(x);
    auto pSec = GetBack_Inl();
    if (pSec == nullptr)return {};
    return pSec->VarList;
}
IBB_VariableList _PROJ_CMD_READ IBR_Section::GetVarListFullCopy(bool PrintExtraData) _PROJ_CMD_BACK_CONST const
{
    IBD_RInterruptF(x);
    auto pSec = GetBack_Inl();
    if (pSec == nullptr)return {};
    return pSec->GetLineList(PrintExtraData);
}
bool _PROJ_CMD_WRITE _PROJ_CMD_CAN_UNDO _PROJ_CMD_UPDATE IBR_Section::DuplicateSection(const IBB_Section_Desc& NewDesc) const
{
    IBD_RInterruptF(x);
    auto pSec = GetBack_Inl();
    if (pSec == nullptr)return false;
    if (!IBF_Inst_Project.Project.CreateNewSection(NewDesc))return false;

    IBF_Inst_Project.UpdateCreateSection(NewDesc);

    auto pNSec = const_cast<IBB_Section*>(IBF_Inst_Project.Project.GetSec(IBB_Project_Index{ NewDesc }));
    if (pNSec == nullptr)return false;
    bool Ret = pNSec->GenerateAsDuplicate(*pSec);

    //TODO: Check if Update Works
    //TODO: Undo Action
    return Ret;
}

bool _PROJ_CMD_WRITE _PROJ_CMD_CAN_UNDO _PROJ_CMD_UPDATE IBR_Section::Rename(const std::string& NewName)
{
    bool Ret = true;
    {
        IBD_RInterruptF(x);
        auto pSec = const_cast<IBB_Section*>(IBF_Inst_Project.Project.GetSec(IBB_Project_Index{ GetDesc() }));
        auto desc = GetDesc(); desc.Sec = NewName;
        auto npSec = const_cast<IBB_Section*>(IBF_Inst_Project.Project.GetSec(IBB_Project_Index{ desc }));
        if (pSec == nullptr || npSec != nullptr)Ret = false;
        else
        {
            auto OldName = pSec->Name;
            Ret = pSec->Rename(NewName);

            auto pIni = pSec->Root;
            auto Node = pIni->Secs.extract(OldName);
            Node.key() = NewName;
            auto sp = pIni->Secs.insert(std::move(Node));
            for (auto& s : pIni->Secs_ByName)if (s == OldName)s = NewName;
        }
    }
    GetDesc().Sec = NewName;
    //Update Contained in Rename so no Extra
    //TODO: Undo Action
    return Ret;
}

bool _PROJ_CMD_WRITE _PROJ_CMD_CAN_UNDO IBR_Section::Register(const std::string& Name, const std::string& IniName) _PROJ_CMD_BACK_CONST const
{
    IBD_RInterruptF(x);
    return IBF_Inst_Project.Project.RegisterSection(Name, IniName, *GetBack_Inl());
}


bool _PROJ_CMD_WRITE _PROJ_CMD_CAN_UNDO _PROJ_CMD_UPDATE IBR_Project::AddModule(
    const std::string& ModuleName,
    const std::vector<std::string>& ParamList,
    const IBB_Section_Desc& MergeDesc)
{
    bool Ret;
    {
        IBD_RInterruptF(x);
        Ret = IBF_Inst_Project.AddModule(IBF_DefaultModuleList_Index{ ModuleName }, IBF_DefaultModuleList_Parameter{ ParamList ,MergeDesc });
    }
    //Update Contained in AddModule so no Extra
    //TODO: Undo Action
    return Ret;
}
bool _PROJ_CMD_WRITE _PROJ_CMD_CAN_UNDO _PROJ_CMD_UPDATE IBR_Project::AddModule(
    int ModuleID,
    const std::vector<std::string>& ParamList,
    const IBB_Section_Desc& MergeDesc)
{
    bool Ret;
    {
        IBD_RInterruptF(x);
        Ret = IBF_Inst_Project.AddModule(IBF_DefaultModuleList_Index{ ModuleID }, IBF_DefaultModuleList_Parameter{ ParamList ,MergeDesc });
    }
    //Update Contained in AddModule so no Extra
    //TODO: Undo Action 
    return Ret;
}

bool _PROJ_CMD_WRITE _PROJ_CMD_UPDATE IBR_Project::UpdateAll()
{
    IBD_RInterruptF(x);
    return IBF_Inst_Project.UpdateAll();
}

bool _PROJ_CMD_WRITE _PROJ_CMD_UPDATE IBR_Project::ForceUpdate()
{
    IBD_RInterruptF(x);
    if (BackThreadID == INT_MAX)return false;
    IBG_SuspendThread(BackThreadID);
    IBRF_CoreBump.IBF_ForceProc();
    IBG_ResumeThread(BackThreadID);
    return IBF_Inst_Project.UpdateAll();
}

_TEXT_UTF8 std::string _PROJ_CMD_READ IBR_Project::GetText(bool PrintExtraData)
{
    IBD_RInterruptF(x);
    return IBF_Inst_Project.GetText(PrintExtraData);
}

IBR_Section _PROJ_CMD_READ IBR_Project::GetSection(const IBB_Section_Desc& Desc)
{
    auto rit = IBR_Rev_SectionMap.find(Desc);
    if (rit == IBR_Rev_SectionMap.end())
    {
        rit = IBR_Rev_SectionMap.insert({ Desc,MaxID }).first;
        IBR_SectionMap.insert({ MaxID,Desc });
        ++MaxID;
    }
    return IBR_Section{ this,rit->second };
}

bool _PROJ_CMD_WRITE _PROJ_CMD_CAN_UNDO _PROJ_CMD_UPDATE IBR_Project::CreateSection(const IBB_Section_Desc& Desc)
{
    bool Ret;
    {
        IBD_RInterruptF(x);
        Ret = IBF_Inst_Project.Project.CreateNewSection(Desc);
        IBF_Inst_Project.UpdateCreateSection(Desc);
    }
    //TODO: Undo Action 
    return Ret;
}

bool _PROJ_CMD_READ IBR_Project::HasSection(const IBB_Section_Desc& Desc)
{
    IBD_RInterruptF(x);
    return IBF_Inst_Project.Project.GetSec(IBB_Project_Index{ Desc }) != nullptr;
}

bool _PROJ_CMD_WRITE _PROJ_CMD_CAN_UNDO _PROJ_CMD_UPDATE IBR_Project::DeleteSection(const IBB_Section_Desc& Desc)
{
    IBD_RInterruptF(x);
    auto ci = const_cast<IBB_Ini*>(IBF_Inst_Project.Project.GetIni(IBB_Project_Index{ Desc }));
    return ci->DeleteSection(Desc.Sec);
}

/*
WRITE:
    ret=Interrupt(Action);
    SendToF(Update);
    Push(UndoAction);
    return ret;

READ:
    Interrupt(Action);
*/
