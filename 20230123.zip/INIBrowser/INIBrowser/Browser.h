#pragma once


#include"FromEngine/Include.h"
#include"FromEngine/global_timer.h"
#include<thread>
#include<chrono>
#include<atomic>
#include<mutex>


#include"FromEngine/Csf.h"
#include"Global.h"

typedef void (*callback_t)();




std::string FontPath = ".\\Resources\\";//ȫ���̲���
std::wstring Defaultpath{ L"C:\\" };
std::string Pathbuf, Desktop, TextEditAboutU8;
std::wstring PathbufW;

HMODULE TElib;

BufString debugbuf;//�ǲ����������ɶҲû��
Ini::IniFile HoverHintInfo;
Ini::IniSection StringSec;
bool StringSecIterAvailable = false;
bool IsInExitProcess = false;

CSFClass DefaultCSF, ProjRa2MD;
CSFClass StringTable[100], GlobalStringTable[100];

int CurrentScreenWidth, CurrentScreenHeight;

bool AnalysisShowINILine = true;

int FnInfoDelay = 1000, FnInfoEndDelay = 5000;
int WaitTimeMsec = 10;//���������INI������INIʱ�ĵȴ�ʱ��

int RScrX, RScrY, ScrX, ScrY;

int ActiveINI = -1;//����ʱ�ɱ�

std::vector<int8_t> IsTicked;
bool SelectMode, WindowMustSync, IsFileChanging;

wchar_t BufW1[5000], BufW2[5000], BufW3[5000], BufW4[5000];
char BufA1[5000], BufA2[5000], BufA3[5000];
wchar_t CurrentDirW[5000];//���õ�ǰĿ¼ʱ�����������������Ҫ��ʱ��
char CurrentDirA[5000];//��ΪOpenFileDialog��ı䵱ǰĿ¼�����Ա�����ǰ����

std::vector<std::string> Hint;//UTF-8�ַ�����
int HintChangeSecs = 5000;
int FPSLimit = -1;

float InitOfsX = -1, TreeOfsX = -1;

int RecentFileLimit = 10;
std::vector<std::string>RecentFilePath;//UTF-8



HWND MainWindowHandle = 0;




int ExitCloseAllFile();


namespace PreLink
{
    GLFWwindow* window;
    ImVec4 clear_color = ImVec4(0.196f, 0.407f, 0.467f, 1.0f);//����ɫ*
    HINSTANCE hInst;
    ImFont* font;

    void CleanUp();
    int OnExit_CleanUp()
    {
        ExitCloseAllFile();
        return 0;
    }
}


int GetPage(int u)
{
    return (u - 1) / KeyPerPage + 1;
}
std::string MinorDir(const std::string& ss)
{
    return std::string(ss.begin() + std::min(ss.find_last_of('\\') + 1, ss.length() - 1), ss.end());
}
bool SelectFilePath(HWND father, std::wstring& strFilePath, const std::wstring& FromPath);


#include"Sese.h"



namespace Browse
{

    template<typename Cont>
    void ShowList(const std::string& suffix, std::vector<Cont>& Ser, int* Page, void (*Callback)(Cont&, int, int))
    {
        int RenderF = (*Page) * KeyPerPage;
        int RenderN = (1 + (*Page)) * KeyPerPage;
        int Sz = Ser.size();
        bool HasPrev = ((*Page) != 0);
        bool HasNext = (RenderN < Sz);
        int RealRF = std::max(RenderF, 0);
        int RealNF = std::min(RenderN, Sz);
        int PageN = GetPage(Sz);
        for (int On = RealRF; On < RealNF; On++)
        {
            Callback(Ser.at(On), On - RealRF + 1, On);
        }
        if (HasPrev || HasNext)
        {
            if (HasPrev)
            {
                if (ImGui::ArrowButton(("prev_" + suffix).c_str(), ImGuiDir_Left))
                {
                    (*Page)--;
                    if (EnableLog)
                    {
                        GlobalLog.AddLog_CurTime(false);
                        GlobalLog.AddLog(("�������һҳ��" + suffix + "����ť��").c_str());
                    }
                }
                ImGui::SameLine();
                ImGui::Text(u8"��һҳ");
                ImGui::SameLine();
            }
            else
            {
                ImGui::PushStyleColor(ImGuiCol_Text, { 0,0,0,0 });
                ImGui::PushStyleColor(ImGuiCol_Button, { 0,0,0,0 });
                ImGui::PushStyleColor(ImGuiCol_ButtonActive, { 0,0,0,0 });
                ImGui::PushStyleColor(ImGuiCol_ButtonHovered, { 0,0,0,0 });
                if (ImGui::ArrowButton(("prev_" + suffix).c_str(), ImGuiDir_Left))
#ifdef SESE
                    SeseCheck()
#endif
                    ;
                ImGui::SameLine();
                ImGui::PopStyleColor(4);
            }
            if ((*Page) + 1 >= 1000)ImGui::SetCursorPosX(FontHeight * 13.0f);
            if ((*Page) + 1 >= 100)ImGui::SetCursorPosX(FontHeight * 12.5f);
            else ImGui::SetCursorPosX(FontHeight * 12.0f);
            if (HasNext)
            {
                ImGui::Text(u8"��һҳ");
                ImGui::SameLine();
                if (ImGui::ArrowButton(("next_" + suffix).c_str(), ImGuiDir_Right))
                {
                    (*Page)++;
                    if (EnableLog)
                    {
                        GlobalLog.AddLog_CurTime(false);
                        GlobalLog.AddLog(("�������һҳ��" + suffix + "����ť��").c_str());
                    }
                }
                ImGui::SameLine();

            }
            ImGui::NewLine();

            if (*Page != 0)
            {
                if (ImGui::ArrowButton(("fpg_" + suffix).c_str(), ImGuiDir_Left))
                {
                    (*Page) = 0;
                    if (EnableLog)
                    {
                        GlobalLog.AddLog_CurTime(false);
                        GlobalLog.AddLog(("����˵�һҳ��" + suffix + "����ť��").c_str());
                    }
                }
                ImGui::SameLine();
                ImGui::Text(u8"��һҳ");
                ImGui::SameLine();
            }
            else
            {
                ImGui::PushStyleColor(ImGuiCol_Text, { 0,0,0,0 });
                ImGui::PushStyleColor(ImGuiCol_Button, { 0,0,0,0 });
                ImGui::PushStyleColor(ImGuiCol_ButtonActive, { 0,0,0,0 });
                ImGui::PushStyleColor(ImGuiCol_ButtonHovered, { 0,0,0,0 });
                ImGui::ArrowButton("OBSOLETE_BUTTON", ImGuiDir_Left);
                ImGui::SameLine();
                ImGui::PopStyleColor(4);
            }
            if ((*Page) + 1 >= 1000)ImGui::SetCursorPosX(FontHeight * 5.5f);
            else ImGui::SetCursorPosX(FontHeight * 6.0f);
            auto PosYText = ImGui::GetCursorPosY();
            ImGui::SetCursorPosY(PosYText - FontHeight * 0.5f);
            ImGui::Text(u8"�ڣ�%d/%d��ҳ", (*Page) + 1, PageN);
            ImGui::SetCursorPosY(PosYText);
            ImGui::SameLine();
            if ((*Page) + 1 >= 1000)ImGui::SetCursorPosX(FontHeight * 13.0f);
            if ((*Page) + 1 >= 100)ImGui::SetCursorPosX(FontHeight * 12.5f);
            else ImGui::SetCursorPosX(FontHeight * 12.0f);
            if ((*Page) + 1 != PageN)
            {
                ImGui::Text(u8"���ҳ");
                ImGui::SameLine();
                if (ImGui::ArrowButton(("lpg_" + suffix).c_str(), ImGuiDir_Right))
                {
                    (*Page) = PageN - 1;
                    if (EnableLog)
                    {
                        GlobalLog.AddLog_CurTime(false);
                        GlobalLog.AddLog(("��������ҳ��" + suffix + "����ť��").c_str());
                    }
                }
                ImGui::SameLine();
            }
            ImGui::NewLine();
        }
    }

   
}














namespace InsertLoad
{
    bool SelectFileName(HWND father, std::string& RetBuf, int& PathOffset, const std::string& InitialPath)//trueȷ��falseȡ��
    {
        OPENFILENAMEA ofn;
        CHAR szFile[296]{};
        CHAR szFileTitle[296] = "ѡ��Ҫ������ļ�";
        memset(&ofn, 0, sizeof(ofn));
        ofn.lStructSize = sizeof(ofn);
        ofn.hwndOwner = father;
        ofn.lpstrFilter = "��������(*_pack.dat)\0*_pack.dat\0�����ļ� (*.*)\0*.*\0\0";
        ofn.lpstrFile = szFile;
        ofn.nMaxFile = sizeof(szFile);
        ofn.lpstrFileTitle = szFileTitle;
        ofn.nMaxFileTitle = sizeof(szFileTitle);
        ofn.lpstrInitialDir = InitialPath.c_str();
        ofn.Flags = OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST | OFN_EXPLORER;
        bool ret = (GetOpenFileNameA(&ofn));
        if (ret)
        {
            if (szFile[0])
            {
                RetBuf = szFile;
                PathOffset = ofn.nFileOffset;
            }
        }
        else
        {
            RetBuf = "";
            PathOffset = 0;
        }
        if (EnableLog)
        {
            GlobalLog.AddLog_CurTime(false);
            GlobalLog.AddLog("ѡ���ļ���");
        }
        return ret;
    }

    std::pair<std::string, int> GetSelectFile(const std::string& FromFile)
    {
        std::string Ret{};
        int RetI{};
        if (SelectFileName(MainWindowHandle, Ret, RetI, FromFile))return { Ret, RetI };
        else return { "",0 };
    }
 

}













































