#pragma once

#include<cstdio>
#include<string>
#include<vector>
#include<cstdint>

class ExtFileClass
{
	FILE* fp;
	bool IsOpen{ false };
public:
	FILE* GetPlain()const
	{
		return fp;
	} 
	bool Open(const char* path, const char* mode, void* Reserved = nullptr)
	{
        (void)Reserved;
        fp = fopen(path, mode);
		return IsOpen = (fp != NULL);
	}
	size_t Read(void* Buf, size_t Size, size_t Count)const
	{
		if (!IsOpen)return 0;
		return fread(Buf, Size, Count, fp);
	}
	size_t Write(const void* Buf, size_t Size, size_t Count)const
	{
		if (!IsOpen)return 0;
		return fwrite(Buf, Size, Count, fp);
	}
	char GetChr()const
	{
		if (!IsOpen)return 0;
		return (char)fgetc(fp);
	}
	bool PutChr(const char Byte)const
	{
		if (!IsOpen)return 0;
		return fputc(Byte, fp)!=EOF;
	}
	bool Ln()const
	{
		return PutChr('\n');
	}
	char* GetStr(char* Buf, size_t Size)const
	{
		if (!IsOpen)return 0;
		return fgets(Buf, Size, fp);
	}
	size_t PutStr(const char* Buf)const
	{
		if (!IsOpen)return 0;
		return fputs(Buf, fp);
	}
	int Close()
	{
		if (!IsOpen)return 0;
		IsOpen = false;
		return fclose(fp);
	}
	int Seek(int Offset,int Base)const
	{
		return fseek(fp,Offset,Base);
	}
	int Position()const
	{
		return ftell(fp);
	}
	bool Eof()const
	{
		if (!IsOpen)return true;
		return feof(fp);
	}
	bool Available()const
	{
		return IsOpen;
	}
    void Rewind()const
    {
        rewind(fp);
    }
    int Flush()const
    {
        return fflush(fp);
    }

    bool ReadData(std::string& Str)const
    {
        static char Buf[32768];
        int64_t Size;
        if (!Read(&Size, sizeof(Size), 1))return false;
        Buf[Read(Buf, 1, (size_t)Size)] = 0;
        Str = Buf;
        return true;
    }
    bool WriteData(const std::string& Str)const
    {
        int64_t Size = Str.size();
        if (!Write(&Size, sizeof(Size), 1))return false;
        Write(Str.c_str(), 1, Str.size());
        return true;
    }
    template<typename T>
    bool WriteData(const T& Data)const
    {
        return Write(&Data, sizeof(T), 1);
    }
    template<typename T>
    bool ReadData(T& Data)const
    {
        return Read(&Data, sizeof(T), 1);
    }
    template<typename T>
    bool WriteVector(const std::vector<T>& Data)const//�����ԣ���
    {
        if (!WriteData((int64_t)Data.size()))return false;
        return Write(Data.data(), sizeof(T), Data.size());
    }
    template<typename T>
    bool ReadVector(std::vector<T>& Data)const//�����ԣ���
    {
        int64_t Size;
        if (!ReadData(Size))return false;
        Data.resize(Size);
        return Read(Data.data(), sizeof(T), Size);
    }

	~ExtFileClass()
	{
		if (IsOpen)Close();
	}
};

