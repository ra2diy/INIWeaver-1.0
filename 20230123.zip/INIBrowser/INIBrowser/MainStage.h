// Copyright (C) 2019 Nomango

#pragma once



#include"FromEngine/SpIni.h"
#include"IBFront.h"
#include"IBRender.h"
#include"Browser.h"
#include"Pack.h"
#include<ShlObj.h>

const char* AppName= u8"INI�����";


int ExitCloseAllFile();

int WindowSizeAdjustX = 15, WindowSizeAdjustY = 5;

int DynamicDataXDelta, DynamicDataYDelta;

bool Await{ true };
bool ProjectLoad_Final{ false };

void ControlPanel();
void MainMenuPanel();

void ControlPanel_Setting();
void ControlPanel_About();
void ControlPanel_Debug();


std::vector<std::function<void(int)>>DelayWindow;

RECT FinalWP;

int CurrentINIPage = 0;

int ExitCloseAllFile()
{
	if (EnableLog)
	{
		GlobalLog.AddLog_CurTime(false);
		GlobalLog.AddLog("�������ڽ������С�");
	}

    IBR_Inst_Setting.CallSaveSetting();

    while (!IBR_Inst_Setting.IsSaveSettingComplete());

	if (EnableLog)
	{
		GlobalLog.AddLog_CurTime(false);
		GlobalLog.AddLog("�����Ѿ��������С�");
	}

	return 0;
}



namespace ImGui
{
    ImVec2 GetLineEndPos()
    {
        return { ImGui::GetWindowPos().x + ImGui::GetWindowWidth(),ImGui::GetCursorScreenPos().y };
    }
    ImVec2 GetLineBeginPos()
    {
        return { ImGui::GetWindowPos().x ,ImGui::GetCursorScreenPos().y };
    }
    bool IsWindowClicked(ImGuiMouseButton Button)
    {
        return ImGui::IsWindowHovered() && ImGui::IsMouseClicked(Button);
    }
}

dImVec2 operator+(const dImVec2 a, const dImVec2 b) { return { a.x + b.x,a.y + b.y }; }
dImVec2 operator-(const dImVec2 a, const dImVec2 b) { return { a.x - b.x,a.y - b.y }; }
ImVec4 operator+(const ImVec4 a, const ImVec4 b) { return { a.x + b.x,a.y + b.y,a.z + b.z,a.w + b.w }; }
dImVec2 operator/(const dImVec2 a, const double b) { return { a.x / b,a.y / b }; }
dImVec2 operator*(const dImVec2 a, const double b) { return { a.x * b,a.y * b }; }




float SectionTextScale, PrevSTScale;
dImVec2 ClipZoneUL, ClipZoneDR, ClipZoneCenter;
float LWidth;


namespace _TempSelectLink
{
    const ImColor ForegroundCoverColor(0, 145, 255, 35);
    const ImColor ForegroundMarkColor(0, 100, 255, 255);
    const ImColor LinkingLineColor(255, 168, 21, 255);
    const ImColor LegalLineColor(255, 138, 5, 255);
    const ImColor IllegalLineColor(255, 45, 45, 255);
    bool InLinkProcess;
    int LinkFrom, LinkAt;
    ImVec2 MouseStartPos;
    
    void InLink(int From, int At)
    {
        if (!InLinkProcess)
        {
            InLinkProcess = true;
            LinkFrom = From;
            LinkAt = At;
            MouseStartPos = ImGui::GetLineEndPos();
        }
    }
    int OutLink()
    {
        if (InLinkProcess)
        {
            InLinkProcess = false;
            return LinkAt;
        }
        return -1;
    }
    bool IsInLink()
    {
        return InLinkProcess;
    }

    struct SectionRect
    {
        ImVec2 PosUL, PosDR;
    };
    std::vector<SectionRect>SecRect;
    void AddSecRect()
    {
        SecRect.emplace_back(SectionRect{});
        SecRect.back().PosUL = ImGui::GetWindowPos();
        SecRect.back().PosDR = {
            SecRect.back().PosUL.x + ImGui::GetWindowSize().x,
            SecRect.back().PosUL.y + ImGui::GetWindowSize().y };
    }
    void ClearLoop()
    {
        SecRect.clear();
    }

}

const int MaxSec = 2000;
int InitialNSec = 5, CurrentNSec = InitialNSec;
bool PressA[MaxSec]{}, PressB[MaxSec]{};
std::vector<int>Linkto[MaxSec];
std::vector<dImVec2>LinkStartPosL[MaxSec];
std::vector<dImVec2>LinkStartPosR[MaxSec];
dImVec2 WindowStartPosUL[MaxSec];
dImVec2 WindowStartPosUR[MaxSec];
dImVec2 WindowZoomDirection[MaxSec];
double RealHeight[MaxSec];
bool WindowFocus[MaxSec];

dImVec2 InitialWindowZoomDirection[MaxSec];
double InitialSTScale;
int PrevSet = 0;


namespace _TempView
{
    //const ImColor ForegroundCoverColor(0, 145, 255, 35);
    //const ImColor ForegroundMarkColor(0, 100, 255, 255);
    const ImColor FocusWindowColor(170, 204, 244, 255);
    const ImColor ClipFrameLineColor(108, 255, 45, 255);
    const ImColor CenterCrossColor(255, 5, 5, 255);

    ImVec2 ViewSize;//Set in INIBrowser.cpp
    ImVec2 OffsetPos;
    double ViewScale = 20;

    void DrawView(ImDrawList* dl,ImVec2 Pos)
    {
        ImVec2 CPos = Pos + (ViewSize * 0.5);
        dImVec2 VOffset = dImVec2(OffsetPos) / ViewScale;
        dl->AddRectFilled(Pos, Pos + ViewSize, ImColor(PreLink::clear_color));

        for (int i = 0; i < CurrentNSec; i++)
        {
            ImVec2 VCI = WindowZoomDirection[i] / (double)SectionTextScale / ViewScale ;
            for (int j : Linkto[i])
            {
                if (j == -1)continue;
                ImVec2 VCJ = WindowZoomDirection[j] / (double)SectionTextScale / ViewScale ;
                dl->AddBezierCurve(
                    VCI + CPos + VOffset,
                    ImVec2{ (3 * VCJ.x + VCI.x) / 4 ,VCI.y } + CPos + VOffset,
                    ImVec2{ (3 * VCI.x + VCJ.x) / 4 ,VCJ.y } + CPos + VOffset,
                    VCJ + CPos + VOffset,
                     _TempSelectLink::LegalLineColor,1.0f);
            }
        }
        for (int i = 0; i < CurrentNSec; i++)
        {
            if (WindowFocus[i])continue;
            ImVec2 VCT = WindowZoomDirection[i] / (double)SectionTextScale;
            ImVec2 WD = { (float)WindowStartPosUR[i].x - (float)WindowStartPosUL[i].x ,(float)RealHeight[i]};
            ImVec2 WUL = (VCT - WD / 2) / ViewScale;
            ImVec2 WDR = (VCT + WD / 2) / ViewScale;
            dl->AddRectFilled(WUL + CPos + VOffset, WDR + CPos + VOffset,ImColor(ImGui::GetStyleColorVec4(ImGuiCol_WindowBg)));
            dl->AddRect(WUL + CPos + VOffset, WDR + CPos + VOffset, ImColor(ImGui::GetStyleColorVec4(ImGuiCol_Border)), 0.0f, 0, 1.0f);

        }
        for (int i = 0; i < CurrentNSec; i++)
        {
            if (!WindowFocus[i])continue;
            ImVec2 VCT = WindowZoomDirection[i] / (double)SectionTextScale;
            ImVec2 WD = { (float)WindowStartPosUR[i].x - (float)WindowStartPosUL[i].x ,(float)RealHeight[i] };
            ImVec2 WUL = (VCT - WD / 2) / ViewScale;
            ImVec2 WDR = (VCT + WD / 2) / ViewScale;
            dl->AddRectFilled(WUL + CPos + VOffset, WDR + CPos + VOffset, FocusWindowColor);
            dl->AddRect(WUL + CPos + VOffset, WDR + CPos + VOffset, ImColor(ImGui::GetStyleColorVec4(ImGuiCol_Border)), 0.0f, 0, 1.0f);

        }

        dl->AddLine(CPos - ImVec2{ 3, 0 }, CPos + ImVec2{ 4, 0 }, CenterCrossColor, 1.0f);
        dl->AddLine(CPos - ImVec2{ 0, 3 }, CPos + ImVec2{ 0, 4 }, CenterCrossColor, 1.0f);

        dImVec2 ClipSize = (ClipZoneDR - ClipZoneUL) / (double)SectionTextScale;
        dImVec2 ClipVSize = ClipSize / ViewScale;
        dImVec2 ClipVUL = VOffset - (ClipVSize * 0.5);
        dl->AddRect(ClipVUL + CPos, ClipVUL + ClipVSize + CPos, ClipFrameLineColor, 0.0f, 0, 1.0f);
        
    }

    void ChangeOffsetPos(ImVec2 ClickRel)
    {
        OffsetPos=(ClickRel - ViewSize * 0.5) * ViewScale;
    }
}
ImVec2 PrevOffsetPos;


void ControlPanelTemp(int iButton)
{
    ImGui::Text(u8"UI������");

    _TempSelectLink::AddSecRect();

    std::vector<int>ReFill{};
    std::vector<dImVec2>ReFillPosL, ReFillPosR;
    int iLink = 0;
    for (int n : Linkto[iButton])
    {
        if (n == -1)
        {
            ImGui::PushID(n + 0x114513);
            if (!ImGui::SmallButton(u8"ɾ��"))
            {
                ReFill.push_back(n);
                ReFillPosR.push_back(ImGui::GetLineEndPos());
                ReFillPosL.push_back(ImGui::GetLineBeginPos());
            }
            ImGui::SameLine();
            ImGui::Text(u8"δ����");
            ImGui::SameLine();
            ImGui::PushID(n + 0x114512);
            if (ImGui::SmallButton("+"))
            {
                _TempSelectLink::InLink(iButton, iLink);
            }
        }
        else
        {
            ImGui::PushID(n + 0x114513);
            if (!ImGui::SmallButton(u8"ɾ��"))
            {
                ReFill.push_back(n);
                ReFillPosR.push_back(ImGui::GetLineEndPos());
                ReFillPosL.push_back(ImGui::GetLineBeginPos());
            }
            ImGui::SameLine();
            ImGui::Text(u8"���ӵ� %d ", n);
            ImGui::SameLine();
            ImGui::PushID(n + 0x114514);
            if (ImGui::ArrowButton("loopex", ImGuiDir_Right))
            {
                IBR_Inst_Debug.AddMsgOnce([=]() {ImGui::Text(u8"Window %d : Focus %d ", iButton, n); });
                DelayWindow.push_back([=](int u) {if (u == n) {
                    ImGui::SetNextWindowFocus(); ImGui::SetNextWindowCollapsed(false);
                }});
            }
        }
        iLink++;
    }

    
    WindowFocus[iButton] = ImGui::IsWindowFocused();
    Linkto[iButton] = ReFill;
    LinkStartPosL[iButton] = ReFillPosL;
    LinkStartPosR[iButton] = ReFillPosR;
    if (ImGui::Button(u8"����+"))
    {
        Linkto[iButton].push_back(-1);
        LinkStartPosL[iButton].push_back({ 0.0f,0.0f });
        LinkStartPosR[iButton].push_back({ 0.0f,0.0f });
    }
    if (_TempSelectLink::IsInLink())
    {
        if (ImGui::IsWindowClicked(ImGuiMouseButton_Left))
        {
            Linkto[_TempSelectLink::LinkFrom][_TempSelectLink::OutLink()] = iButton;
        }
        if (ImGui::IsMouseClicked(ImGuiMouseButton_Right))
        {
            Linkto[_TempSelectLink::LinkFrom][_TempSelectLink::OutLink()] = -1;
        }
    }



}

bool WaitingInsertLoad{ false };
int A_INI = -2, A_Sec = -2;
ETimer::TimerClass HintTimer;

BufString TempTargetPath;

bool ChangeWithFontSize;//EVENT : FONT_SCALE_CHANGE

bool PanelOnHold = false;
int MenuType = 0;
bool MenuChangeShow = true;
callback_t MenuPage[3] =
{
    ControlPanel_Setting,
    ControlPanel_About,
    ControlPanel_Debug,
};

void ControlPanel()
{
    static int UseHint = 0;
    static bool First = true;
    static ExtFileClass DynamicData;

    _TempSelectLink::ClearLoop();
    IBRF_CoreBump.IBR_AutoProc();

    GetWindowRect(MainWindowHandle, &FinalWP);

    if (First)
    {
        DynamicData.Open(".\\Resources\\dynamic.dat", "wb");
        DynamicDataXDelta = ScrX - (FinalWP.right - FinalWP.left);
        DynamicDataYDelta = ScrY - (FinalWP.bottom - FinalWP.top);
        if (EnableLog)
        {
            GlobalLog.AddLog_CurTime(false);
            GlobalLog.AddLog("��ѭ����ʼ��ת��");
        }
        First = false;
    }

    CurrentScreenWidth = FinalWP.right - FinalWP.left + DynamicDataXDelta;
    CurrentScreenHeight = FinalWP.bottom - FinalWP.top + DynamicDataYDelta;
    DynamicData.Rewind();
    DynamicData.WriteData((int64_t)(CurrentScreenWidth));
    DynamicData.WriteData((int64_t)(CurrentScreenHeight));
    DynamicData.WriteData((double)SectionTextScale);
    DynamicData.WriteData(_TempView::OffsetPos.x);
    DynamicData.WriteData(_TempView::OffsetPos.y);
    DynamicData.Flush();


    ImGui::Begin("INIBrowserMainMenu", nullptr,
        ImGuiWindowFlags_NoTitleBar |
        ImGuiWindowFlags_NoNav |
        ImGuiWindowFlags_NoCollapse |
        //ImGuiWindowFlags_NoBackground |
        ImGuiWindowFlags_NoResize |
        ImGuiWindowFlags_NoMove );
    ImGui::SetWindowPos({ 0,-FontHeight * 0.0f });
    ImGui::SetWindowSize({ (float)(FinalWP.right - FinalWP.left - WindowSizeAdjustX),FontHeight * 2.0f });

    MainMenuPanel();

    ImGui::SameLine();
    ImGui::SetCursorPosX(ImGui::GetWindowWidth() - 14.0f * FontHeight);
    ImGui::Text(u8"INI����� V%s ƽ��FPS %.1f", Version.c_str(), ImGui::GetIO().Framerate);

    ImGui::End();



    if (MenuChangeShow)
    {
        ImGui::SetNextWindowCollapsed(false);
        MenuChangeShow = false;
    }
    ImGui::Begin(u8"���˵�", nullptr,
        //ImGuiWindowFlags_NoTitleBar |
        ImGuiWindowFlags_NoNav |
        //ImGuiWindowFlags_NoCollapse |
        //ImGuiWindowFlags_NoBackground |
        //ImGuiWindowFlags_NoResize |
        ImGuiWindowFlags_NoMove );
    ImGui::SetWindowPos({ 0,FontHeight * 2.0f - WindowSizeAdjustY });
    ImGui::SetWindowSize({ std::max(ImGui::GetWindowWidth(),
        std::min(((float)(FinalWP.right - FinalWP.left - WindowSizeAdjustX)) / 4 ,400.0f)),
       (float)(FinalWP.bottom - FinalWP.top) - FontHeight * 3.5f + WindowSizeAdjustY});

    LWidth = ImGui::IsWindowCollapsed() ? 0.0f : ImGui::GetWindowWidth();

    MenuPage[MenuType]();

    ImGui::NewLine(); ImGui::NewLine();
	ImGui::End();

    IBR_Inst_Debug.ClearMsgCycle();




    auto DelayWindowB = DelayWindow;
    DelayWindow.clear();
    auto RFontHeight = FontHeight;
    FontHeight = (int)(FontHeight * SectionTextScale);
    ClipZoneUL = dImVec2{ (double)LWidth,FontHeight * 2.0 - WindowSizeAdjustY };
    ClipZoneDR = dImVec2{ (double)CurrentScreenWidth ,(double)CurrentScreenHeight - FontHeight * 1.5 };
    dImVec2 PrevClipZoneCenter = ClipZoneCenter;
    ClipZoneCenter = (ClipZoneUL + ClipZoneDR) / 2.0;
    bool ChangeWithClipZone = (fabs(PrevClipZoneCenter.x - ClipZoneCenter.x) > 0.001//EVENT : CLIP_ZONE_CHANGE
        || fabs(PrevClipZoneCenter.y - ClipZoneCenter.y) > 0.001);
    double WindowHeightMin = FontHeight * 12.0, PrevWindowHeightMin = (int)(RFontHeight * PrevSTScale) * 12.0;
    ImVec2 OffsetDelta = PrevOffsetPos - _TempView::OffsetPos;
    bool ChangeWithOffset = fabs(OffsetDelta.x) > 0.001 || fabs(OffsetDelta.y) > 0.001;

    IBR_Inst_Debug.AddMsgCycle([=]() {ImGui::Text("PrevSet = %s", (PrevSet?"true":"false")); });


    for (int i = 0; i < CurrentNSec; i++)
    {
        for (auto f : DelayWindowB)f(i);

        ImGui::Begin((u8"�Ӳ˵� - " + std::to_string(i)).c_str(), nullptr, ImGuiWindowFlags_NoClamping);
        ImGui::SetWindowFontScale(SectionTextScale);
        ImGui::PushClipRect(ClipZoneUL, ClipZoneDR, true);

        IBR_Inst_Debug.AddMsgCycle([=]() {ImGui::Text("Window %d Pos = ( %.2f, %.2f )", i, WindowStartPosUL[i].x, WindowStartPosUL[i].y); });
        //IBR_Inst_Debug.AddMsgCycle([=]() {ImGui::Text("Window %d Height = %.2f", i, RealHeight[i]); });

        ImVec2 SWSize{ FontHeight * 12.0f, 0.0f };
        if (fabs(WindowStartPosUL[i].x) < 0.01 || fabs(WindowStartPosUL[i].y) < 0.01)
            { WindowStartPosUL[i] = ImGui::GetWindowPos(); }
        if (fabs(RealHeight[i]) < 0.001) { RealHeight[i] = std::max(ImGui::GetWindowHeight(), FontHeight * 12.0f); }
        dImVec2 SWCenter = WindowStartPosUL[i] + (SWSize / 2.0);
        if (fabs(WindowZoomDirection[i].x) < 0.01 || fabs(WindowZoomDirection[i].y) < 0.01)
            { WindowZoomDirection[i] = SWCenter - ClipZoneCenter; }


        if (ChangeWithFontSize)
        {

            if (PrevSet <= i)
            {
                ++PrevSet;
                InitialWindowZoomDirection[i] = WindowZoomDirection[i];
                InitialSTScale = PrevSTScale;
            }

            WindowZoomDirection[i] = InitialWindowZoomDirection[i] * SectionTextScale / InitialSTScale;
            SWCenter = WindowZoomDirection[i] + ClipZoneCenter;
            WindowStartPosUL[i] = SWCenter - (SWSize / 2.0);
            WindowStartPosUR[i] = WindowStartPosUL[i];
            WindowStartPosUR[i].x += ImGui::GetWindowWidth();
            SWSize.y = (float)RealHeight[i];
            ImGui::SetWindowPos(WindowStartPosUL[i]);

            if (fabs(RealHeight[i] - PrevWindowHeightMin) < FontHeight + 2.0)
            {
                SWSize.y = (float)WindowHeightMin;
                RealHeight[i] = WindowHeightMin;
                ImGui::SetWindowSize(SWSize);
            }
            else
            {
                RealHeight[i] = RealHeight[i] * SectionTextScale / PrevSTScale;
                SWSize.y = (float)RealHeight[i];
                ImGui::SetWindowSize(SWSize);
            }

        }
        else
        {
            if (ChangeWithClipZone)
            {
                PrevSet = 0;
                //DebugVecOnce.push_back([=]() {ImGui::Text("Window %d Change Clip", i); });

                SWCenter = WindowZoomDirection[i] + ClipZoneCenter;
                WindowStartPosUL[i] = SWCenter - (SWSize / 2.0);
                WindowStartPosUR[i] = WindowStartPosUL[i];
                WindowStartPosUR[i].x += ImGui::GetWindowWidth();
                SWSize.y = (float)RealHeight[i];
                ImGui::SetWindowPos(WindowStartPosUL[i]);
            }
            else if (ChangeWithOffset)
            {
                WindowZoomDirection[i] = WindowZoomDirection[i] + OffsetDelta;
                SWCenter = WindowZoomDirection[i] + ClipZoneCenter;
                WindowStartPosUL[i] = SWCenter - (SWSize / 2.0);
                WindowStartPosUR[i] = WindowStartPosUL[i];
                WindowStartPosUR[i].x += ImGui::GetWindowWidth();
                SWSize.y = (float)RealHeight[i];
                ImGui::SetWindowPos(WindowStartPosUL[i]);
            }
            else
            {
                if (fabs((WindowStartPosUL[i] - ImGui::GetWindowPos()).max()) > 1.0 )
                {
                    PrevSet = 0;
                    //DebugVecOnce.push_back([=]() {ImGui::Text("Window %d Change Pos", i); });

                    WindowStartPosUL[i] = ImGui::GetWindowPos();
                    WindowStartPosUR[i] = ImGui::GetWindowPos();
                    WindowStartPosUR[i].x += ImGui::GetWindowWidth();
                    SWCenter = WindowStartPosUL[i] + (SWSize / 2.0);
                    WindowZoomDirection[i] = SWCenter - ClipZoneCenter;
                }

                if (fabs((float)RealHeight[i] - ImGui::GetWindowHeight()) > 2.0f)
                {
                    PrevSet = 0;
                    //DebugVecOnce.push_back([=]() {ImGui::Text("Window %d Change", i); });
                }
                SWSize.y = std::max(ImGui::GetWindowHeight(), (float)WindowHeightMin);
                RealHeight[i] = SWSize.y;
                ImGui::SetWindowSize(SWSize);
                
            }
        }

        /* {
            ImDrawList* DList = ImGui::GetForegroundDrawList();
            DList->AddCircle(WindowStartPosUL[i], 5.0, _TempSelectLink::IllegalLineColor, 0, 2.0f);
            DList->AddCircle(WindowStartPosUL[i] + (SWSize / 2.0), 5.0, _TempSelectLink::IllegalLineColor, 0, 2.0f);
            DList->AddCircle(WindowStartPosUL[i] + SWSize, 5.0, _TempSelectLink::IllegalLineColor, 0, 2.0f);
            DList->AddRect(WindowStartPosUL[i], WindowStartPosUL[i] + SWSize, _TempSelectLink::LinkingLineColor, 0.0f, 0, 2.0f);
            DList->AddLine(WindowStartPosUL[i] + (SWSize / 2.0), ClipZoneCenter, _TempSelectLink::ForegroundMarkColor, 8.0f);
        }*/

        ControlPanelTemp(i);
        ImGui::End();
    }


    ImDrawList* DList = ImGui::GetForegroundDrawList();
    ImDrawList* BList = ImGui::GetBackgroundDrawList();
    if (_TempSelectLink::IsInLink())
    {
        for (auto sq : _TempSelectLink::SecRect)
        {
            DList->AddRectFilled(sq.PosUL, sq.PosDR, _TempSelectLink::ForegroundCoverColor);
        }
        DList->AddLine(_TempSelectLink::MouseStartPos, ImGui::GetMousePos(), _TempSelectLink::LinkingLineColor, FontHeight / 5.0f);
    }
    for (int i = 0; i < CurrentNSec; i++)
    {
        for (int j = 0; j < (int)Linkto[i].size(); j++)
        {
            if (Linkto[i][j] == -1)continue;
            else if (Linkto[i][j] >= CurrentNSec)
            {
                auto par = LinkStartPosR[i][j];
                par.x -= FontHeight * 0.5f;
                par.y -= FontHeight * 0.5f;
                BList->AddLine(par, dImVec2{ par.x + FontHeight * 3.0, par.y},
                    _TempSelectLink::IllegalLineColor, FontHeight / 4.0f);
            }
            else
            {
                auto pal = LinkStartPosL[i][j];
                auto par = LinkStartPosR[i][j];
                auto pbl = WindowStartPosUL[Linkto[i][j]];
                auto pbr = WindowStartPosUR[Linkto[i][j]];
                pal.x += FontHeight * 0.5f;
                pal.y -= FontHeight * 0.5f;
                par.x -= FontHeight * 0.5f;
                par.y -= FontHeight * 0.5f;
                pbl.x += FontHeight * 0.5f;
                pbl.y += FontHeight * 0.5f;
                pbr.x -= FontHeight * 0.5f;
                pbr.y += FontHeight * 0.5f;
                ImVec2 pa, pb;
                pa = pal.x >= pbr.x ? pal : par;
                pb = pbl.x >= par.x ? pbl : pbr;

                pa.y += FontHeight / 6.0f;
                BList->AddBezierCurve(pa, { (pa.x + 4 * pb.x) / 5,pa.y }, { (4 * pa.x + pb.x) / 5,pb.y }, pb,
                    _TempSelectLink::LegalLineColor, FontHeight / 6.0f);
                pa.y -= FontHeight / 6.0f;
                BList->AddBezierCurve(pa, { (pa.x + 4 * pb.x) / 5,pa.y }, { (4 * pa.x + pb.x) / 5,pb.y }, pb,
                    _TempSelectLink::LegalLineColor, FontHeight / 6.0f);
                pa.y -= FontHeight / 6.0f;
                BList->AddBezierCurve(pa, { (pa.x + 4 * pb.x) / 5,pa.y }, { (4 * pa.x + pb.x) / 5,pb.y }, pb,
                    _TempSelectLink::LegalLineColor, FontHeight / 6.0f);
            }
        }
    }
    
    PrevOffsetPos = _TempView::OffsetPos;
    FontHeight = RFontHeight;

    if (!Hint.empty())
    {
        if (HintTimer.GetMilli() > HintChangeSecs)
        {
            UseHint = rand() % Hint.size();
            HintTimer.Set();
        }
    }
    {
        DList->AddRectFilled({ 0.0f,(float)CurrentScreenHeight - FontHeight * 1.5f },
            { (float)CurrentScreenWidth ,(float)CurrentScreenHeight },
            ImColor(ImGui::GetStyleColorVec4(ImGuiCol_WindowBg)));
        DList->AddLine({ 0.0f,(float)CurrentScreenHeight - FontHeight * 1.5f },
            { (float)CurrentScreenWidth,(float)CurrentScreenHeight - FontHeight * 1.5f },
            ImColor(ImGui::GetStyleColorVec4(ImGuiCol_Border)), 1.0f);
        if (_TempSelectLink::IsInLink())
        {
            const char* Tx = u8"�������ѡ���Ҽ�ȡ��";
            DList->AddText({ FontHeight * 0.8f,(float)CurrentScreenHeight - FontHeight * 1.25f },
                ImColor(ImGui::GetStyleColorVec4(ImGuiCol_Text)),
                Tx, Tx + strlen(Tx));
        }
        else
        {
            if (!Hint.empty())
            {
                DList->AddText({ FontHeight * 0.8f,(float)CurrentScreenHeight - FontHeight * 1.25f },
                    ImColor(ImGui::GetStyleColorVec4(ImGuiCol_Text)),
                    Hint[UseHint].c_str(), Hint[UseHint].c_str() + Hint[UseHint].size());
            }
        }
    }
    

}

void MainMenuPanel()
{
    //ImGui::PushStyleColor(ImGuiCol_Text, { 0,0,0,0 });
    ImGui::PushStyleColor(ImGuiCol_Button, { 0,0,0,0 });
    //ImGui::PushStyleColor(ImGuiCol_ButtonActive, { 0,0,0,0 });
    //ImGui::PushStyleColor(ImGuiCol_ButtonHovered, { 0,0,0,0 });  ;
    
    if (ImGui::SmallButton(u8"����"))
    {
        MenuType = 0;
        MenuChangeShow = true;
        if (EnableLog)
        {
            GlobalLog.AddLog_CurTime(false);
            GlobalLog.AddLog("�����\"����\"�˵�");
        }
    }ImGui::SameLine();
    if (ImGui::SmallButton(u8"����"))
    {
        MenuType = 1;
        MenuChangeShow = true;
        if (EnableLog)
        {
            GlobalLog.AddLog_CurTime(false);
            GlobalLog.AddLog("�����\"����\"�˵�");
        }
    }
    ImGui::SameLine();
    if (ImGui::SmallButton(u8"����"))
    {
        MenuType = 2;
        MenuChangeShow = true;
        if (EnableLog)
        {
            GlobalLog.AddLog_CurTime(false);
            GlobalLog.AddLog("�����\"����\"�˵�");
        }
    }
    ImGui::PopStyleColor(1);
}

void ControlPanel_Setting()
{
    IBR_Inst_Setting.RenderUI();
}

void ControlPanel_Debug()
{
    ImGui::Text(u8"������Ϣ��");

    
    if (ImGui::Button(u8"�ֶ�+"))
    {
        if (CurrentNSec < MaxSec)++CurrentNSec;
    }ImGui::SameLine();
    if (ImGui::Button(u8"�ֶ�-"))
    {
        if (CurrentNSec > 1)--CurrentNSec;
    }
    static float TmpScale = 100.0f * SectionTextScale;
    ImGui::SliderFloat(u8"���ű���", &TmpScale, 25.0f, 200.0f, "%.0f%%", ImGuiSliderFlags_Logarithmic);
    TmpScale = floor(TmpScale / 5.0f) * 5.0f;
    PrevSTScale = SectionTextScale;
    SectionTextScale = TmpScale / 100.0f;
    ChangeWithFontSize = (fabs(PrevSTScale - SectionTextScale) > 0.001f);

    ImGui::Text(u8"��ͼ");
    ImGui::BeginChildFrame(114514 + 2, _TempView::ViewSize + ImVec2{5, 8});
    auto CRect = ImGui::GetCursorScreenPos();
    ImGui::Dummy(_TempView::ViewSize);
    {
        bool CHover = ImGui::IsItemHovered();
        IBR_Inst_Debug.AddMsgCycle([=]() {ImGui::Text("View Hovered = %s", (CHover ? "true" : "false")); });
        IBR_Inst_Debug.AddMsgCycle([=]() {ImGui::Text("View Pos = ( %.2f, %.2f )", CRect.x, CRect.y); });
        IBR_Inst_Debug.AddMsgCycle([=]() {ImGui::Text("Offset Pos = ( %.2f, %.2f )", _TempView::OffsetPos.x, _TempView::OffsetPos.y); });
    }
    if (ImGui::IsItemHovered() && ImGui::IsMouseDown(ImGuiMouseButton_Left))
    {
        auto MP = ImGui::GetIO().MousePos;
        _TempView::ChangeOffsetPos(MP - CRect);
    }
    _TempView::DrawView(ImGui::GetWindowDrawList(), CRect);
    ImGui::EndChildFrame();


    IBR_Inst_Debug.RenderUI();

}

void ControlPanel_About()
{
    ImGui::TextWrapped(u8"INI����� V%s", Version.c_str());
    ImGui::TextWrapped(u8"��������� 2022��11��");
    ImGui::Separator();
    ImGui::TextWrapped(u8"���ߣ�std::iron_hammer");
    ImGui::TextWrapped(u8"QQ������֮����2482911962��");
    ImGui::TextWrapped(u8"���ɣ���030504");
    ImGui::TextWrapped(u8"���䣺2482911962@qq.com");
    ImGui::Separator();
    ImGui::TextWrapped(u8"�������ӣ�");
    ImGui::TextWrapped(u8"����������ɫ����ɣ�"); //ImGui::SameLine();
    if (ImGui::Button(u8"��������##A"))
    {
        ImGui::LogToClipboard();
        ImGui::LogText("https://tieba.baidu.com/p/8005920823");
        ImGui::LogFinish();
    }ImGui::SameLine();
    if (ImGui::Button(u8"������##A"))
    {
        ::ShellExecuteA(nullptr, "open", "https://tieba.baidu.com/p/8005920823", NULL, NULL, SW_SHOWNORMAL);
    }
    ImGui::TextWrapped(u8"�������������ս�ɣ�"); //ImGui::SameLine();
    if (ImGui::Button(u8"��������##B"))
    {
        ImGui::LogToClipboard();
        ImGui::LogText("https://tieba.baidu.com/p/8005924464");
        ImGui::LogFinish();
    }ImGui::SameLine();
    if (ImGui::Button(u8"������##B"))
    {
        ::ShellExecuteA(nullptr, "open", "https://tieba.baidu.com/p/8005924464", NULL, NULL, SW_SHOWNORMAL);
    }
    ImGui::TextWrapped(u8"�������������ս�3ini�ɣ�"); //ImGui::SameLine();
    if (ImGui::Button(u8"��������##C"))
    {
        ImGui::LogToClipboard();
        ImGui::LogText("https://tieba.baidu.com/p/8133473361");
        ImGui::LogFinish();
    }ImGui::SameLine();
    if (ImGui::Button(u8"������##C"))
    {
        ::ShellExecuteA(nullptr, "open", "https://tieba.baidu.com/p/8133473361", NULL, NULL, SW_SHOWNORMAL);
    }
    ImGui::TextWrapped(u8"ע������������ͬ������");
    ImGui::TextWrapped(u8"ȫ���汾���أ��ٶ����̣�"); //ImGui::SameLine();
    if (ImGui::Button(u8"��������##D"))
    {
        ImGui::LogToClipboard();
        ImGui::LogText("https://pan.baidu.com/s/1EpzAuIQfbU1-7sjb2YJocg?pwd=EASB");
        ImGui::LogFinish();
    }ImGui::SameLine();
    if (ImGui::Button(u8"������##D"))
    {
        ::ShellExecuteA(nullptr, "open", "https://pan.baidu.com/s/1EpzAuIQfbU1-7sjb2YJocg?pwd=EASB", NULL, NULL, SW_SHOWNORMAL);
    }
    ImGui::TextWrapped(u8"��ȡ�룺EASB");
}



